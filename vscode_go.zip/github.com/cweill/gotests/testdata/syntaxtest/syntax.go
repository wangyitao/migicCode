package syntaxtest

import "os"

func Not(this *os.File) string { return "the test file has syntax errors" }
