package blanktest

import "os"

func Not(this *os.File) string { return "check the test file" }
