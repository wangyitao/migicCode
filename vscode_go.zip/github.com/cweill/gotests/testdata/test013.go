package testdata

func Foo13(f func()) error { return nil }
