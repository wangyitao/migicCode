package testdata

func Foo8(b *Bar) (*Bar, error) { return nil, nil }
