package testdata

type TestReceiver struct{}

func (t *TestReceiver) FooMethod() error {
	return nil
}
