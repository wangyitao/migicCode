// <<<<< extract,9,2,10,46,printB,pass
package main

import "fmt"

func main() {
	a := 3 + 0
	b := 4 + 0
	b = 5 + 0
	fmt.Println("The variable a and b is:", b, a)
	fmt.Println("The new value of b is:", b)
}
