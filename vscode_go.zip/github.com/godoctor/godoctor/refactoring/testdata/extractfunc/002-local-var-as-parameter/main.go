// <<<<< extract,9,2,10,37,printB,pass
package main

import "fmt"

func main() {
	a := 3
	b := 4
	b = 5
	fmt.Println("The variable b is:", b)
	fmt.Println("The variable a is:", a, b)
}
