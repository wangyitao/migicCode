package mypackage 

import "fmt"

func SecondFunction() {             
	
    x := MyFunction(10)

    fmt.Println(x)
}
