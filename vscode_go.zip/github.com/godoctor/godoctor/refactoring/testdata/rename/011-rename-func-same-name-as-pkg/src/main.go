package main

import "fmt"
import "Mypackage"
//Test for renaming an imported function
func main() {                               
	fmt.Println(Mypackage.Mypackage(5))     
}
