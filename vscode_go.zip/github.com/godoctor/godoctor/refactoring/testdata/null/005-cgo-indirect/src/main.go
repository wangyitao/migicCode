package main // <<<<< null,1,1,1,1,false,pass

import "pkg"
import "fmt"

func main() {
	pkg.DoPackageStuff()
	fmt.Println("Done")
}
