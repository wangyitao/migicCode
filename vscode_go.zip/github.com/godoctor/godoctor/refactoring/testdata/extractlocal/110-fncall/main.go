package main

import "fmt"

func dbl(n int) int {
	return 2 * n
}

func main() {
	dbl(4) // <<<<< var,10,2,10,7,variable,pass
	fmt.Printf("Test\n")
}
