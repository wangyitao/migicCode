package main

import (
	"fmt"
	"math"
)

func main() {
	x := 5.0
	for x < 10 { // <<<<< var,10,5,10,11,newVar,fail
		x++
	}
	if math.Mod(x, 5) == 0 {
		fmt.Println("divisible by 5:")
	}
}
