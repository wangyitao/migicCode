package main

import "fmt"

func main() {
	fmt.Println("Hello, 世界") // <<<<< var,6,2,6,29,newVar,fail
}
