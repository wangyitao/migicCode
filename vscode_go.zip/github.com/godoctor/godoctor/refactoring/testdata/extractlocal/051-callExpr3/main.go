package main

import "fmt"

func main() {
	fmt.Println("Hello, 世界") // <<<<< var,6,14,6,28,newVar,pass
}
