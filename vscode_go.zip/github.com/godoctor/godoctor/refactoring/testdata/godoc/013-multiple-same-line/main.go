package main // <<<<< godoc,1,1,1,1,pass

type ( a int; B int; c int; D int; E struct{} )

func main() {
}
