package foo
func Foo() {}
