package bar
func Bar() {}
